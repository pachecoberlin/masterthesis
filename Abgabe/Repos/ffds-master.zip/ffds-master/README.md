# Fahrradfahrer Detektionssystem - FFDS

Cyclist detection on images of opencv supported. The ANN is YOLOv3 a CNN with FPN and ResNet feature. The results are published over a ROS node. OPENCV, NVIDIA GPU with computing power 6.1 and CUDA 10 is needed.

This Code was firstly created on a machine with:
* Ubuntu 18.04
* OpenCV Version 3.4.3
* ROS Melodic
* CUDA 10.1
* NVIDIA GEFORCE 1050 TI
* NVIDIA Driver 418.56
* Driver for inbuild camera

# Guide to run it on any machine

##.bashrc
###Custom Paths for Cuda
export PATH=/usr/local/cuda-10.0/bin${PATH:+:${PATH}}
export LD_LIBRARY_PATH=/usr/local/cuda-10.0/lib64${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}

###opencv paths
export LD_LIBRARY_PATH=/usr/local/lib${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}

###ROS paths
source /opt/ros/melodic/setup.bash
export EDITOR='nano -w'
source ~/data/ffds/devel/setup.bash

##
$LD_LIBRARY_PATH = /home/pacheco/data/ffds/devel/lib:/opt/ros/melodic/lib:/usr/local/lib:/usr/local/cuda-10.0/lib64

## Die CMakeList bearbeiten
Den Pfad richtig einstellen