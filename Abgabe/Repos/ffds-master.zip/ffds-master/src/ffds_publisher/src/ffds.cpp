#include "darknet.h"
#include "ffds.hpp"
#include "publisher.cpp"

char* cfgfile = "/home/pacheco/data/ffds/ffds.cfg";
char* weightfile = "/home/pacheco/data/ffds/ffds.weights";
static network *net;
static image buff[3];
static image buff_letter[3];
static int buff_index = 0;
static void * cap;
static float fps = 0;
static float demo_thresh = 0;
static float demo_hier = .5;
static int running = 0;
static int demo_frame = 3;
static int demo_index = 0;
static float *predictions[3];
static float *avg;
static int demo_done = 0;
static int demo_total = 3;
double demo_time;

void remember_network_ffds(network *net) {
	int i;
	int count = 0;
	for (i = 0; i < net->n; ++i) {
		layer l = net->layers[i];
		if (l.type == YOLO || l.type == REGION || l.type == DETECTION) {
			memcpy(predictions[demo_index] + count, net->layers[i].output, sizeof(float) * l.outputs);
			count += l.outputs;
		}
	}
}

detection *avg_predictions_ffds(network *net, int *nboxes) {
	int i, j;
	int count = 0;

	fill_cpu(demo_total, 0, avg, 1);
	for (j = 0; j < demo_frame; ++j) {
		axpy_cpu(demo_total, 1. / demo_frame, predictions[j], 1, avg, 1);
	}
	for (i = 0; i < net->n; ++i) {
		layer l = net->layers[i];
		if (l.type == YOLO || l.type == REGION || l.type == DETECTION) {
			memcpy(l.output, avg + count, sizeof(float) * l.outputs);
			count += l.outputs;
		}
	}
	detection *dets = get_network_boxes(net, buff[0].w, buff[0].h, demo_thresh, demo_hier, 0, 1, nboxes);
	return dets;
}

void pass_detections(void *ptr) {
	detections *dets;
	dets = (detections*) ptr;
	int i;
	int detection_counter = 0;
	box detected[dets->count];
	for (i = 0; i < dets->count; ++i) {
		if (dets->dets[i].prob[0] > 0.3) {
			detection_counter++;
			box b = dets->dets[i].bbox;
			detected[detection_counter] = b;
		}
	}
	send_detections(detected, detection_counter);
	free_detections(dets->dets, dets->count);
}
void *detect_in_thread_ffds(void *ptr) {
	running = 1;
	float nms = .4;
	layer l = net->layers[net->n - 1];
	float *X = buff_letter[(buff_index + 2) % 3].data;
	network_predict(net, X);
	remember_network_ffds(net);
	detection *dets = 0;
	int nboxes = 0;
	if (demo_done) {
		return 0;
	}
	dets = avg_predictions_ffds(net, &nboxes);
	if (nms > 0)
		do_nms_obj(dets, nboxes, l.classes, nms);
	pthread_t send_thread;
	detections detections;
	detections.count = nboxes;
	detections.dets = dets;
	pass_detections(&detections);
//	if (pthread_create(&send_thread, 0, send_detections, detections))
//		error("Thread creation failed");
	demo_index = (demo_index + 1) % demo_frame;
	running = 0;
	return 0;
}
void *fetch_in_thread_ffds(void *ptr) {
	free_image(buff[buff_index]);
	buff[buff_index] = get_image_from_stream(cap);
	if (buff[buff_index].data == 0) {
		demo_done = 1;
		return 0;
	}
	letterbox_image_into(buff[buff_index], net->w, net->h, buff_letter[buff_index]);
	return 0;
}
int main(int argc, char **argv) {
	pthread_t detect_thread;
	pthread_t fetch_thread;
	cuda_set_device(0);
	net = load_network(cfgfile, weightfile, 0);
	set_batch_network(net, 1);

	int i;
	demo_total = size_network(net);
	//predictions = (float*)calloc(demo_frame, sizeof(float*));
	for (i = 0; i < demo_frame; ++i) {
		predictions[i] = (float*) calloc(demo_total, sizeof(float));
	}
//	avg=calloc(demo_total, sizeof(float));
	avg = (float*) calloc(demo_total, sizeof(float));

	cap = open_video_stream(0, 0, 0, 0, 0);
	initialize_bus();
	if (!cap)
		error("Couldn't connect to webcam.\n");

	buff[0] = get_image_from_stream((void *) cap);
	buff[1] = copy_image(buff[0]);
	buff[2] = copy_image(buff[0]);
	buff_letter[0] = letterbox_image(buff[0], net->w, net->h);
	buff_letter[1] = letterbox_image(buff[0], net->w, net->h);
	buff_letter[2] = letterbox_image(buff[0], net->w, net->h);
	demo_time = what_time_is_it_now();

	while (!demo_done) {
		buff_index = (buff_index + 1) % 3;
		if (pthread_create(&fetch_thread, 0, fetch_in_thread_ffds, 0))
			error("Thread creation failed");
		if (pthread_create(&detect_thread, 0, detect_in_thread_ffds, 0))
			error("Thread creation failed");
		fps = 1. / (what_time_is_it_now() - demo_time);
		printf("FPS: %.0f\n", fps);
		demo_time = what_time_is_it_now();
		pthread_join(fetch_thread, 0);
		pthread_join(detect_thread, 0);
	}

}
