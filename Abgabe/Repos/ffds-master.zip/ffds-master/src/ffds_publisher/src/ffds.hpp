#ifndef FFDS_H
#define FFDS_H

typedef struct detections {
	detection *dets;
	int count;
} detections;

#endif
