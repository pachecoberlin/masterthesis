#include <sstream>
#include "ros/ros.h"
#include "ros/rate.h"
#include "std_msgs/String.h"
#include "ffds.hpp"
/**
 * This class is sending bounding boxes(x,y,width,height) relativ to the image size of the camera in a CSV list as String over the ROS system with topic name "CyclistDetectOnCAM1".
 @author Alexander Wachtberger
 */
ros::Publisher chatter_pub;

int initialize_bus() {
	int wtf = 0;
	ros::init(wtf, NULL, "ffds_publisher");
	ros::NodeHandle n;
	chatter_pub = n.advertise < std_msgs::String > ("CyclistDetectOnCAM1", 1);
	return ros::ok();
}
void send_detections(box *detected, int count) {
	std_msgs::String msg;
	std::stringstream ss;
//	ss << "YOO";
	for (int i = 0; i < count; ++i) {
		ss << detected[i].x << " " << detected[i].y << " " << detected[i].w << " " << detected[i].h << ";";
	}
	msg.data = ss.str();
	if (ros::ok()) {
		chatter_pub.publish(msg);
	} else {
		//TODO error handling
	}
}
