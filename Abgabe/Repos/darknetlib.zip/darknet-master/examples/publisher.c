#include "darknet.h"
#include "ffds.h"

int initialize_bus() {
	return 0;
}
void send_detections(box *detected,int count){
	for (int i = 0; i < count; ++i) {
		printf("%f\n", detected[i].x);
	}
}
