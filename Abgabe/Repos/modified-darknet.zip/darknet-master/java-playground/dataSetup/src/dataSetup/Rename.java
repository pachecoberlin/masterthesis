package dataSetup;

import java.io.File;

public class Rename {

	public static void main(String[] args) {
		work("test");
		work("train");
		work("valid");
	}

	private static void work(String str) {
		var f = new File(String
				.format("/home/pacheco/data/Master/bilddaten/cyclist_benchmark/labels/%s/tsinghuaDaimlerDataset", str));
		var fileArray = f.listFiles();
		for (int i = 0; i < fileArray.length; i++) {
			if (fileArray[i].isDirectory()) {
				continue;
			}
			fileArray[i].renameTo(new File(fileArray[i].getAbsolutePath().replace("labels","leftImg8bit")));
		}
	}

}
