package dataSetup;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

public class DataSetup {

	public static void main(String[] args) {
		work("test");
		work("train");
		work("valid");
	}

	private static void work(String str) {
		var f = new File(String
				.format("/home/pacheco/data/Master/bilddaten/cyclist_benchmark/images/%s/tsinghuaDaimlerDataset", str));
		var fileArray = f.listFiles();
		try {
			var data = new FileWriter(
					String.format("/home/pacheco/data/eclipse-workspaces/java-playground/dataSetup/%s.txt", str));
			AtomicBoolean firstline = new AtomicBoolean(true);

			for (int i = 0; i < fileArray.length; i++) {
				if (fileArray[i].isDirectory()) {
					continue;
				}
				data.write(firstline.get() ? fileArray[i].getAbsolutePath():"\n"+fileArray[i].getAbsolutePath());
				firstline.set(false);
			}
			data.flush();
			data.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
