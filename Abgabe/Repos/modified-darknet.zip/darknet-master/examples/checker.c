/*
 * checker.c
 *
 *  Created on: 14.12.2018
 *      Author: Alexander Wachtberger
 */

#include "darknet.h"
#include <dirent.h>
#include <stdio.h>

static int boxcount = 0;
box boxes[20];

void draw_boxes(image im, image ** alphabet) {

	float red = 0;
	float green = 1;
	float blue = 0;
	float rgb[3];
	int width = im.h * .006;

	//width = prob*20+2;

	rgb[0] = red;
	rgb[1] = green;
	rgb[2] = blue;

	for (int i = 0; i < boxcount; i++) {
		box b = boxes[i];
		//printf("%f %f %f %f\n", b.x, b.y, b.w, b.h);

		int left = (b.x - b.w / 2.) * im.w;
		int right = (b.x + b.w / 2.) * im.w;
		int top = (b.y - b.h / 2.) * im.h;
		int bot = (b.y + b.h / 2.) * im.h;

		if (left < 0)
			left = 0;
		if (right > im.w - 1)
			right = im.w - 1;
		if (top < 0)
			top = 0;
		if (bot > im.h - 1)
			bot = im.h - 1;
		draw_box_width(im, left, top, right, bot, width, red, green, blue);
		if (alphabet) {
			image label = get_label(alphabet, "BIKER", (im.h * .03));
			draw_label(im, top + width, left, label, rgb);
			free_image(label);
		}
	}

}

int getboxes(char *filename) {
	FILE * fp;
	char * line = NULL;
	size_t len = 0;
	ssize_t read;
	boxcount = 0;

	fp = fopen(filename, "r");
	if (fp == NULL)
		return boxcount;

	while ((read = getline(&line, &len, fp)) != -1) {
//			printf("Retrieved line of length %zu:\n", read);
//			printf("%s", line);
		int class;

		sscanf(line, "%d %f %f %f %f", &class, &boxes[boxcount].x, &boxes[boxcount].y, &boxes[boxcount].w,
				&boxes[boxcount].h);
//			sscanf(line, "%d %f %f %f %f", &class, &x, &y, &w, &h);
//			printf("%d %f %f %f %f", class, x, y, w, h);
		boxcount++;
	}

	fclose(fp);
	if (line)
		free(line);
	return boxcount;
}

int showImageWithBB(const char* filename, image im, image** alphabet) {
	char labelpath[255];
	find_replace(filename, "images", "labels", labelpath);
	//TODO geht nur für jpg dateien und png
	find_replace(labelpath, "jpg", "txt", labelpath);
	find_replace(labelpath, "png", "txt", labelpath);
	if (!getboxes(labelpath)) {
	//	return -1;
	}
	if (im.w == 10) {
		printf("image not loaded correctly");
		return -1;
	}
	draw_boxes(im, alphabet);
	printf("Showing %s\n", filename);
	return show_image(im, "predictions", 0);
}
//bikexxxxxxx.jpg = 15 chars
void check_labeling(char* dirname, int argc, char** argv) {
	char buff[256];
	char *input = buff;
	char buff1[256];
	char *actualFilename = buff1;
	char buff5[256];
	char *gute = buff5;
	char buff6[256];
	char *schlechte = buff6;
	struct dirent *dir;
	DIR *d;
	int index;
	int pressed_key;
	int quit;
	int offset;
	quit = 0;
	index = find_int_arg(argc, argv, "--offset", 0);
	sprintf(gute, "%s/gute.txt", dirname);
	sprintf(schlechte, "%s/schlechte.txt", dirname);
	FILE *fp;
	make_window("predictions", 512, 512, 0);
	image **alphabet = load_alphabet();
	if (dirname) {
		d = opendir(dirname);
	} else {
		printf("no directory specified");
		return;
	}
	if (d) {
		while (!quit) {
			//zeig actualfilename an und hol eingabe
			sprintf(actualFilename, "%s/bike%07d.jpg", dirname,index);
			strncpy(input, actualFilename, 256);
			image im = load_image_color(input, 0, 0);
			pressed_key = showImageWithBB(actualFilename, im, alphabet);

			if (pressed_key == -1) {
				printf("skipping to next\n");
				pressed_key=83;
			}
			//je nach eingabe:
			//links filenames austauschen, index--, mehr als 2 zurück geht nicht

			switch (pressed_key) {
			case 2424832:   // <-
			case 65361:     // <-
			case 91:		// [
			case 81:		// <-
				index--;
				break;
				//rechts wieder vor bis zu filename und danach einlesen, index++
			case 2555904:   // ->
			case 65363:     // ->
			case 93:		// ]
			case 83:		// ->
				index++;
				break;
			case 82: //oben: speichern in gute.txt
				printf("saving image to gut\n");
			    fp = fopen(gute, "a");
	            fprintf(fp, actualFilename);
	            fprintf(fp, "\n");
	            fclose(fp);

//				find_replace(actualFilename, "images", "gut", actualFilename);
//				find_replace(actualFilename, ".png", "", actualFilename);
//				find_replace(actualFilename, ".jpg", "", actualFilename);
				//save_image_options(load_image_color(input, 0, 0), actualFilename, PNG, 100);
//				printf("Saving Done\n");
				//TODO loeschen aus schlecht wenn vorhanden
				break;
			case 84: //unten: speichere in schlecht und löschen aus gut wenn vorhanden
				printf("saving image to schlecht\n");
				fp = fopen(schlechte, "a");
				fprintf(fp, actualFilename);
				fprintf(fp, "\n");
				fclose(fp);
//				find_replace(actualFilename, "images", "schlecht", actualFilename);
//				find_replace(actualFilename, ".png", "", actualFilename);
//				save_image_options(load_image_color(input, 0, 0), actualFilename, PNG, 100);
//				printf("Saving Done\n");
				//TODO loeschen aus gut wenn vorhanden
				break;
			case 27://esc = exit
				quit = 42;
				break;
			default:
				;
			}
			free_image(im);
		}
		closedir(d);
	}
}
/**
 * alt bzw für Benchmark verwendet
 */
void check_labeling_old(char* dirname, int argc, char** argv) {
	char buff[256];
	char *input = buff;
	char buff1[256];
	char *actualFilename = buff1;
	char buff2[256];
	char *filename = buff2;
	char buff3[256];
	char *filename1 = buff3;
	char buff4[256];
	char *filename2 = buff4;
	char buff5[256];
	char *gute = buff5;
	char buff6[256];
	char *schlechte = buff6;
	struct dirent *dir;
	DIR *d;
	int index;
	int pressed_key;
	int quit;
	int nrOfChecked;
	int offset;
	nrOfChecked=3;
	quit = 0;
	offset = find_int_arg(argc, argv, "--offset", 0);
	sprintf(gute, "%s/gute.txt", dirname);
	sprintf(schlechte, "%s/schlechte.txt", dirname);
	FILE *fp;
	make_window("predictions", 512, 512, 0);
	image **alphabet = load_alphabet();

	if (dirname) {
		d = opendir(dirname);
	} else {
		printf("no directory specified");
		return;
	}
	if (d) {
		while ((dir = readdir(d)) != NULL && nrOfChecked<offset) {
			if (dir->d_type == DT_REG) {
				nrOfChecked++;
			}
		}

		//lies die ersten drei ein und index auf -2
		index = -2;
		while ((dir = readdir(d)) != NULL) {
			printf("%s\n", dir->d_name);
			if (dir->d_type == DT_REG) {
				if(0==strcmp(dir->d_name,"gute.txt"))continue;
				if(0==strcmp(dir->d_name,"schlechte.txt"))continue;
				if (index == 0) {
					sprintf(filename, "%s/%s", dirname, dir->d_name);
					index = -2;
					break;
				} else if (index == -1) {
					sprintf(filename1, "%s/%s", dirname, dir->d_name);
					index++;
				} else if (index == -2) {
					sprintf(filename2, "%s/%s", dirname, dir->d_name);
					index++;
				}
			}
		}
		if(dir==NULL) quit=42;
		//loop
		while (!quit) {
			//zeig actualfilename an und hol eingabe

			if (index == 0) {
				strncpy(actualFilename, filename, 256);
			} else if (index == -1) {
				strncpy(actualFilename, filename1, 256);
			} else if (index == -2) {
				strncpy(actualFilename, filename2, 256);
			}
			strncpy(input, actualFilename, 256);
			image im = load_image_color(input, 0, 0);
			pressed_key = showImageWithBB(actualFilename, im, alphabet);
			printf("Showing %s\n", actualFilename);

			if (pressed_key == -1) {
				printf("skipping to next\n");
				pressed_key=83;
			}
			//je nach eingabe:
			//links filenames austauschen, index--, mehr als 2 zurück geht nicht

			switch (pressed_key) {
			case 2424832:   // <-
			case 65361:     // <-
			case 91:		// [
			case 81:		// <-
				if (index == -2) {
					printf("Geht nicht weiter zurueck!\n");
				} else {
					index--;
				}
				break;
				//rechts wieder vor bis zu filename und danach einlesen, index++
			case 2555904:   // ->
			case 65363:     // ->
			case 93:		// ]
			case 83:		// ->
				if (index == 0) {
					strncpy(filename2, filename1, 256);
					strncpy(filename1, filename, 256);
					//check solange nach der nächsten Datei bis entweder eine datei am start
//					oder keine einträge mehr am start
					while ((dir = readdir(d)) != NULL) {
						if (dir->d_type == DT_REG) {
							sprintf(filename, "%s/%s", dirname, dir->d_name);
							printf("Checked images: %d\n",nrOfChecked);
							nrOfChecked++;
							break;
						}
					}
					if (dir == NULL) {
						quit = 42;
						break;
					}
				} else {
					index++;
				}
				break;

				//TODO das loadimage und save image in extra thread aufrufen.
				//oben speichere in gut und löschen aus schlecht wenn vorhanden
			case 82:
				printf("saving image to gut\n");
			    fp = fopen(gute, "a");
	            fprintf(fp, actualFilename);
	            fprintf(fp, "\n");
	            fclose(fp);

//				find_replace(actualFilename, "images", "gut", actualFilename);
//				find_replace(actualFilename, ".png", "", actualFilename);
//				find_replace(actualFilename, ".jpg", "", actualFilename);
				//save_image_options(load_image_color(input, 0, 0), actualFilename, PNG, 100);
//				printf("Saving Done\n");
				//TODO loeschen aus schlecht wenn vorhanden
				break;
				//unten speichere in schlecht und löschen aus gut wenn vorhanden
			case 84:
				printf("saving image to schlecht\n");
				fp = fopen(schlechte, "a");
				fprintf(fp, actualFilename);
				fprintf(fp, "\n");
				fclose(fp);
//				find_replace(actualFilename, "images", "schlecht", actualFilename);
//				find_replace(actualFilename, ".png", "", actualFilename);
//				save_image_options(load_image_color(input, 0, 0), actualFilename, PNG, 100);
//				printf("Saving Done\n");
				//TODO loeschen aus gut wenn vorhanden
				break;
			case 27://esc = exit
				quit = 42;
				break;
			default:
				;
			}
			free_image(im);
		}
		closedir(d);
	}
}

void check_label(char *filename) {
	char buff[256];
	char *input = buff;
	char labelpath[255];
	image **alphabet = load_alphabet();
	strncpy(input, filename, 256);
	find_replace(filename, "images", "labels", labelpath);
	find_replace(labelpath, "jpg", "txt", labelpath);
	find_replace(labelpath, "png", "txt", labelpath);
	if (!getboxes(labelpath)) {
		printf("no labels");
		return;
	}
	image im = load_image_color(input, 0, 0);
	if (im.w == 10) {
		printf("image not loaded correctly");
		return;
	}

	draw_boxes(im, alphabet);
	make_window("predictions", 512, 512, 0);
	show_image(im, "predictions", 0);
	free_image(im);
}

